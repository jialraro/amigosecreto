const nombres = [];

function agregarAmigo() {
    const inputNombre = document.getElementById('amigo');
    const nombre = inputNombre.value.trim();

    if (nombre === '') {
        alert('Debes ingresar un nombre.');
        return;
    }

    if (nombres.includes(nombre)) {
        alert('Este nombre ya está en la lista.');
        return;
    }

    nombres.push(nombre);

    const lista = document.getElementById('listaAmigos');
    const item = document.createElement('li');
    item.textContent = nombre;
    lista.appendChild(item);

    inputNombre.value = ''; // Limpia el campo después de agregar
}

function sortearAmigo() {
    if (nombres.length < 2) {
        alert('Debes agregar al menos dos nombres para sortear.');
        return;
    }

    const indiceAleatorio = Math.floor(Math.random() * nombres.length);
    const amigoSorteado = nombres[indiceAleatorio];

    const resultado = document.getElementById('resultado');
    resultado.innerHTML = `<li>🎉 El amigo secreto sorteado es: <strong>${amigoSorteado}</strong> 🎉</li>`;
}
